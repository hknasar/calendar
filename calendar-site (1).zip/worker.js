export default { async fetch(request, env, ctx) {
  const url = new URL(request.url);
  let path = url.pathname;
  if (path.length > 1 && path.endsWith('/')) path = path.slice(0, -1);
  const routes = { '/': '/index.html', '/calendar-2026': '/calendar-2026/index.html', '/indonesia-public-holidays-2026': '/indonesia-public-holidays-2026/index.html', '/islamic-calendar-2026': '/islamic-calendar-2026/index.html', '/javanese-calendar-2026': '/javanese-calendar-2026/index.html', '/school-calendar-2026': '/school-calendar-2026/index.html', '/balinese-calendar-2026': '/balinese-calendar-2026/index.html', '/sinar-mas-calendar-2026': '/sinar-mas-calendar-2026/index.html', '/motogp-calendar-2026': '/motogp-calendar-2026/index.html', '/eid-al-fitr-calendar-2026': '/eid-al-fitr-calendar-2026/index.html', '/ramadan-calendar-2026': '/ramadan-calendar-2026/index.html', '/calendar-2027': '/calendar-2027/index.html', '/key-dates-2026-2027': '/key-dates-2026-2027/index.html' };
  const file = routes[path] || '/index.html';
  // Serve from static assets if using Workers Static Assets, else fallback
  if (env.ASSETS) return env.ASSETS.fetch(new URL(file, request.url));
  return new Response('Missing ASSETS binding. Deploy with Workers Static Assets.', {status: 500});
}}